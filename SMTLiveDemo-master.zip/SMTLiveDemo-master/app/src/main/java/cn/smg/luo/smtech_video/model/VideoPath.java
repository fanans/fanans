package cn.smg.luo.smtech_video.model;

/**
 * @author jl_luo
 * @name: cn.smg.luo.smtech_video.model
 * @description:
 * @date 2016/4/5 10:36
 */

public class VideoPath {
    public static final String testRtmpPath1 = "http://122.227.101.159:80/livehls1-cnc.wasu.cn/hd_qspd/z.m3u8";//rtmp://10.0.0.138:1935/live?vhost=10.100.102.17123/livestream";
    public static final String testRtmpPath2 = "http://116.77.70.98:5080/hls/228v48qf.m3u8";//"rtmp://live.hkstv.hk.lxdns.com/live/hks";
    public static final String testRtmpPath3 = "http://59.120.43.180:17355";
    public static final String testRtmpPath4 = "http://59.120.43.180:17836";

    public static final String tt1_video1 = "http://182.92.189.193:1935/live/h_hanya_1/playlist.m3u8";
    public static final String tt1_video2 = "http://59.120.43.180:17838";
    public static final String tt1_video3 = "http://218.213.227.174:1935/tv/ch3.live/playlist.m3u8";
    public static final String tt1_video4 = "rtmp://live.hkstv.hk.lxdns.com/live/hks";

}
