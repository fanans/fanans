package cn.smg.luo.smtech_video.adapter;

import android.view.View;

/**
 * 描述:RecyclerView的item点击事件监听器
 */
public interface BGAOnRVItemClickListener {
    void onRVItemClick(View v, int position);
}