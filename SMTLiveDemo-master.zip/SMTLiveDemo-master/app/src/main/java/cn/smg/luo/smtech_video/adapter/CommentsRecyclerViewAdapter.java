package cn.smg.luo.smtech_video.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;

import cn.smg.luo.smtech_video.R;
import cn.smg.luo.smtech_video.common.GlideCircleTransform;
import cn.smg.luo.smtech_video.holder.RecyclerHeaderViewHolder;
import cn.smg.luo.smtech_video.holder.RecyclerItemViewHolder;

/**
 * Created by nian_fan on 2016/4/8.
 */
public class CommentsRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private static final int TYPE_HEADER = 2;
    private static final int TYPE_ITEM = 1;

    Context context;
    int toolBarH;
    RecyclerItemViewHolder itemHolder;

    public CommentsRecyclerViewAdapter(Context context, int toolBarH){
        this.context = context;
        this.toolBarH = toolBarH;
    }

    String[] userNames = {"笑笑雨"};

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        //Context context = parent.getContext();
        if (viewType == TYPE_ITEM) {
        final View view = LayoutInflater.from(
                context).inflate(R.layout.item_commnt, parent, false);
            itemHolder = new RecyclerItemViewHolder(view);
            return itemHolder;
        }else if (viewType == TYPE_HEADER) {
//            //final View view = LayoutInflater.from(context).inflate(R.layout.item_commnt, parent, false);
//            View view2 = new View(context);//view.findViewById(R.id.item_head);
//            LinearLayout.LayoutParams para = (LinearLayout.LayoutParams) view2.getLayoutParams();
//            //ViewGroup.LayoutParams para = view2.getLayoutParams();
//            para.width = toolBarH;
//            view2.setLayoutParams(para);
//            MyViewHolder holder = new MyViewHolder(view2);
//
//            return holder;
            final View view = LayoutInflater.from(context).inflate(R.layout.recycler_header, parent, false);
            return new RecyclerHeaderViewHolder(view , toolBarH);
        }
        throw new RuntimeException("There is no type that matches the type "
                + viewType + " + make sure your using types correctly");
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position)
    {
        //holder.iv.setBackgroundResource(mDatas[position]);
        //holder.tv.setText("");
        //ImageView head = (ImageView) holder.iv.findViewById(R.id.ic_head);

        if (!isPositionHeader(position)) {
            itemHolder = (RecyclerItemViewHolder) holder;
            Glide.with(context).load(R.mipmap.ic12)
                    .centerCrop()
                    .crossFade()
                    .transform(new GlideCircleTransform(context))
                    .into(itemHolder.iv);
            //TextView userName = (TextView)holder.tv.findViewById(R.id.txt_username);
            itemHolder.tv.setText(userNames[0]);
            itemHolder.tv.setText(itemHolder.tv.getText() + "" + position);
        }
    }

    @Override
    public int getItemCount()
    {
        return 20;
    }

    @Override
    public int getItemViewType(int position) {
        if (isPositionHeader(position)) {
            return TYPE_HEADER;
        }

        return TYPE_ITEM;
    }

    private boolean isPositionHeader(int position) {
        return position == 0;
    }

//    class MyViewHolder extends RecyclerView.ViewHolder
//    {
//        TextView tv = null;
//        ImageView iv = null;
//
//        public MyViewHolder(View view)
//        {
//            super(view);
//            tv = (TextView) view.findViewById(R.id.txt_username);
//            iv = (ImageView) view.findViewById(R.id.ic_head);
//        }
//    }
}
