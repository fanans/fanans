package cn.smg.luo.smtech_video.holder;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class RecyclerHeaderViewHolder extends RecyclerView.ViewHolder {
    public RecyclerHeaderViewHolder(View itemView ,int h)
    {
        super(itemView);
//        ViewGroup.LayoutParams para = itemView.getLayoutParams();
//        para.height = h;
//        System.out.println("para.height = h::::::::::::::"+h);
//        itemView.setLayoutParams(para);
    }
}
