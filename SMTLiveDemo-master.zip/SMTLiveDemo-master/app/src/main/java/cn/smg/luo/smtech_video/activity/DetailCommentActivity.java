package cn.smg.luo.smtech_video.activity;

import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import butterknife.Bind;
import butterknife.OnClick;
import cn.smg.luo.smtech_video.BaseActivity;
import cn.smg.luo.smtech_video.R;
import cn.smg.luo.smtech_video.adapter.CommentsRecyclerViewAdapter;
import cn.smg.luo.smtech_video.common.FastBlur;
import cn.smg.luo.smtech_video.common.WindowUtils;
import cn.smg.luo.smtech_video.event.HidingScrollListener;

public class DetailCommentActivity extends BaseActivity {

    //@Bind(R.id.ll_info)LinearLayout llInfo;
    //@Bind(R.id.comments_info)FrameLayout commentsInfo;

    /**
     * 背景图片
     */
    @Nullable
    @Bind(R.id.imageBlur)ImageView ivTagBottom;

    @Bind(R.id.rl_comment_send)protected RelativeLayout commentBottomBar;

    @Bind(R.id.recycle_comments)RecyclerView mRecyclerView = null;

    RecyclerView.Adapter mAdapter = null;
    @Bind(R.id.toolbar)Toolbar mToolbar = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_detail_comment);
        initToolbar();
        applyBlur(ivTagBottom, commentBottomBar);//底部评论栏高斯模糊
        //initFragmentInfo(savedInstanceState);
        initRecyclerView();
    }

//    private void initFragmentInfo(Bundle savedInstanceState){
//        // 不过，如果我们要从先前的状态还原，
//        // 则无需执行任何操作而应返回
//        // 否则就会得到重叠的 Fragment 。
//        if (savedInstanceState != null) {
//            return;
//        }
//
//        // 创建一个要放入 Activity 布局中的新 Fragment
//        DetailCommentFragment fragment = new DetailCommentFragment();
//
//        // 如果此 Activity 是通过 Intent 发出的特殊指令来启动的，
//        // 请将该 Intent 的 extras 以参数形式传递给该 Fragment
//        fragment.setArguments(getIntent().getExtras());
//
//        // 将该 Fragment 添加到“fragment_container”FrameLayout 中
//        getSupportFragmentManager().beginTransaction()
//                .add(R.id.comments_info, fragment).commit();
//
//    }

    int toolBarH = 0;
    public void initToolbar(){
        mToolbar.setTitle("");
        setSupportActionBar(mToolbar);
        // Set the padding to match the Status Bar height
        mToolbar.setPadding(0, WindowUtils.getStatusBarHeight(this), 0, 0);
        setStatusBarColor(R.color.colorPrimary);

        int w = View.MeasureSpec.makeMeasureSpec(0,
                View.MeasureSpec.UNSPECIFIED);
        int h = View.MeasureSpec.makeMeasureSpec(0,
                View.MeasureSpec.UNSPECIFIED);
        mToolbar.measure(w, h);
        toolBarH = mToolbar.getMeasuredHeight();
        //int width = mToolbar.getMeasuredWidth();

    }

    public void initRecyclerView() {
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.scrollToPosition(0);
        //mRecyclerView.addOnScrollListener(new TopTrackListener(findViewById(R.id.toolbar)));
        mAdapter = new CommentsRecyclerViewAdapter(this , toolBarH);
        mRecyclerView.setAdapter(mAdapter);

        mRecyclerView.addOnScrollListener(new HidingScrollListener() {
            @Override
            public void onHide() {
                hideViews();
            }

            @Override
            public void onShow() {
                showViews();
            }
        });
    }

    private void hideViews() {
        mToolbar.animate().translationY(-mToolbar.getHeight()).setInterpolator(new AccelerateInterpolator(2));
    }

    private void showViews() {
        mToolbar.animate().translationY(0).setInterpolator(new DecelerateInterpolator(2));
    }

    /**
     * 底部菜单缓存
     */
    Bitmap backBitMap ;

    /**
     * 底部菜单高斯模糊处理
     * @param backImg 对应模糊处理的图片
     * @param ly 底部菜单栏
     */
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void applyBlur(final ImageView backImg, final View ly) {
        if(backBitMap!=null){
            return;
        }
        backImg.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener() {
            @Override
            public boolean onPreDraw() {
                backImg.getViewTreeObserver().removeOnPreDrawListener(this);
                backImg.buildDrawingCache();

                Bitmap bmp = backImg.getDrawingCache();
                backBitMap = FastBlur.doBlur(getApplicationContext(), bmp, 20, true);
                int sdk = Build.VERSION.SDK_INT;
                if (sdk < Build.VERSION_CODES.JELLY_BEAN) {
                    ly.setBackgroundDrawable(new BitmapDrawable(getResources(), backBitMap));
                } else {
                    ly.setBackground(new BitmapDrawable(getResources(), backBitMap));
                }
                bmp.recycle();
                commentBottomBar.setAlpha(0.9f);
                return true;
            }
        });
    }

    @OnClick({R.id.btn_back})
    void clickPlay(View view){finish();}

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(backBitMap!=null){
            backBitMap.recycle();
            backBitMap = null;
        }
        //EventBus.getDefault().unregister(this);
        //ButterKnife.reset(this);
        //VolleySingleton.getInstance(context).cancleAllReq(TAG);
    }

}
