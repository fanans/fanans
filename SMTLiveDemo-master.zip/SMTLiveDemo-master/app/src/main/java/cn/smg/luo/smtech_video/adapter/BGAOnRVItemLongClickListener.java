package cn.smg.luo.smtech_video.adapter;

import android.view.View;

/**
 * 描述:RecyclerView的item长按事件监听器
 */
public interface BGAOnRVItemLongClickListener {
    boolean onRVItemLongClick(View v, int position);
}