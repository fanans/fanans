package cn.smg.luo.smtech_video.holder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import cn.smg.luo.smtech_video.R;


public class RecyclerItemViewHolder extends RecyclerView.ViewHolder {

    //private final TextView mItemTextView;
    public TextView tv = null;
    public ImageView iv = null;
    public RecyclerItemViewHolder(View view) {
        super(view);

        tv = (TextView) view.findViewById(R.id.txt_username);
        iv = (ImageView) view.findViewById(R.id.ic_head);
    }

    //public static RecyclerItemViewHolder newInstance(View parent) {
        //TextView itemTextView = (TextView) parent.findViewById(R.id.itemTextView);
        //final View view = LayoutInflater.from().inflate(R.layout.item_commnt, parent, false);
        //return new RecyclerItemViewHolder(view);
    //}

    //public void setItemText(CharSequence text) {
        //mItemTextView.setText(text);
    //}

}
